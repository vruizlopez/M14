from flask import Flask, render_template, request
from random import randrange
app = Flask(__name__)
random = randrange(1,99);
@app.route('/')
def hello():
	return "En construccion"
	
@app.route('/templates')
def templates():
	return render_template('template.html')

@app.route('/calendari')
def calendari():
	return render_template('cal.html')
	
@app.route('/sudoku')
def sudoku():
	return render_template('sudoku.html')
	
@app.route('/checkemail')
def email():
	return render_template('checkemail.html',methods=["GET","POST"])	
	
@app.route('/numero', methods=['GET', 'POST'])
def endevina():
    miss = 'Intenta adivinar el numero (1,99):';
    miss2 = '';
    global random
    print random
    if request.method == 'POST':
        numero = request.form['num']
        numero = int(numero)
        if random == numero:
            miss = 'Buen trabajo! Has adivinado el numero'
            miss2 = random;
            random = randrange(1,99)
            print random
        else:
            if(random>numero):
                miss = 'Tu estimacion es muy baja'
            else:
                miss = 'Tu estimacion es muy alta.'
   
    return render_template('numero.html', missatge1 = miss, missatge2 = miss2)	
if __name__ == '__main__':
	app.run()				

